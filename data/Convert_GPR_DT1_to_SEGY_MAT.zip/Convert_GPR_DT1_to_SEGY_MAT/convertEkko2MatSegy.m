% ******************************************************************************
% *** By Sanaz Esmaeili, USF, 2017
% *** Updated by Sajad Jazayeri, USF, 2020
% *** This code will decode and convert all GPR files made by 
% sensors&software to *.mat and *.segy files
% *** This code will work for a single input file as well as multiple choices
% ******************************************************************************

%% load data file(s)
clear all;
[filenameInputGPR,filepathInput]=uigetfile({'*.DT1'},'MultiSelect','on',...
        'Select GPR File(S) that you want to convert to MATLAB format');
    
%% read and convert
if char(filenameInputGPR) ~= 0

    if isa(filenameInputGPR,'cell')%**** multiselect
        sources = numel(filenameInputGPR);
        for i= 1: sources
            filenameInputGPR{i} = upper(filenameInputGPR{i});   %becuase in old version DVL names are uppercase and new version lowercase
            filenameInput = strrep(filenameInputGPR{i}, '.DT1', '');
            ekko2matSEGY(filenameInput);
            clear ans
        end
    else %**** oneselect
        filenameInputGPR = upper(filenameInputGPR);  %becuase in old version DVL names are uppercase and new version lowercase
        filenameInput = strrep(filenameInputGPR, '.DT1', '');
        [A,x,t,timestamp,h,m,s] = ekko2matSEGY(filenameInput);
        % A: GPR data 
        % x: distance along the profile (i.e. location of the antenna
        % center)
        % t: time series in ms
        % timestamp: HHMMSS of data collection
        % h: HH
        % m: MM
        % s: SS
        clear ans
    end
else
    return
end
clear all;