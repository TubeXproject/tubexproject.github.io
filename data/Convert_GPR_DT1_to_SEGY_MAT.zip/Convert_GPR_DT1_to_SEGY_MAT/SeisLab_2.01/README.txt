SeisLab 2.01

This folder contains a folder, S4M, with Matlab functions for seismic and 
well-log analysis, in the following collectively called SeisLab.

Folder "Other" contains support functions written by others and available
from the Matlab Central Program Exchange. 

A manual in PDF format explains the philosophy behind the design of the
functions in SeisLab and the way they can be used. For good measure, I have 
also added a few sample scripts (verba docent, exempla trahunt).

To run SeisLab functions, copy this folder to your computer and add 
the folder S4M and its subfolders to your Matlab path (please note that
folders that start with "@" are class directories and need not be included 
explicitly in the Matlab path; Matlab will find them anyway; the same 
is true for "private" folders). I recommended that you run the 
sample scripts to ascertain that the installation was successful.
The folder HelpFiles need not be included in the Matlab path either as it 
contains only text files that provide instructions for the use of 
certain figures that expect user input.

I do not promise any kind of support for these functions since I have ceased
to maintain code for Matlab versions prior to R14.

If you use Matlab R2007a or higher you might try SeisLab 3.0, which is 
now available from the Matlab File Exchange.

ER
