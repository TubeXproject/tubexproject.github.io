% Seislab_examples

%	Run all examples for the SeisLab distribution
disp('Example 1 *****************************************************')
Seismic_examples1
disp('Example 2 *****************************************************')
Seismic_examples2
disp('Example 3 *****************************************************')
Seismic_log_examples1
disp('Example 4 *****************************************************')
Log_examples1
disp('Script completed')