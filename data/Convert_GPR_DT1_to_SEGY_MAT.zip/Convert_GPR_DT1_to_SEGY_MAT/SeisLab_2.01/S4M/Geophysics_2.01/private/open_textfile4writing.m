function [fid,filename]=open_textfile4writing(filename)
% Open an ASCII text file for writing
%
% Written by: E. R.: January 19, 2006
% Last updated: April 19, 2006: remember path to file
%
%           [fid,filename]=open_textfile4writing(filename)
% INPUT
% filename  name of file to open
%           if isempty(filename) a file selection box will be opened
%           the filename can also be an extension in the form '*.ext'
% OUTPUT
% fid       file identifier
%           if file is not found "fid" is set to -1 and an error message is printed
% filename  name of the file found
%           File name and path are also stored in S4M.filename and
%           S4M.filepath, respectively, and the path is store in S4M.table_path

global S4M

%	Open file for writing
if ~isempty(filename)
   fid=fopen(filename,'wt');
   [filepath,name,extension]=fileparts(filename);
   if ~isempty(extension)  &  ...
       ismember(extension,{'tbl','txt','asc','dat','.tbl','.txt','.asc','.dat'})
         S4M.table_path=filepath;
   end 
   S4M.filename=[name,extension];
   S4M.filepath=filepath;

else
   fid=-1;
   extension='txt';
end

if fid == -1
   [filename,ierr]=get_filename4w(extension);
   if ierr
      return
   end
   fid=fopen(filename,'wt');
   if fid < 0
      disp(['... unable to create requested file "', filename,'"']);
      return
   end
end
