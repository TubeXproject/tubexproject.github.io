function run_presets_if_needed
% Function runs set-up function "presets" in case it has not yet been run.
% This avoids an abort that would otherwise happen because subsequent code
% accesses a field of S4M.
%
% Written by: E. R.: Decemver 12, 2005
% Last updated:

global S4M

if isempty(S4M)
   presets
   S4M.script='';
   S4M.plot_label='';
end
