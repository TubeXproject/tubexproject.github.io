function wlog=l_dtp2vp(wlog,varargin)
% Compute P-velocity from the sonic curve; if a V-velocity curve alredy exists
% a message is printed to the command window and "wlog" is returned unchanged.
% To add an additional P-velocity give it a different name, e.g.
%              l_dtp2vp(wlog,{'vp','new_vp'})
%
% Written by: E. R.: April 16, 2006
% Last updated:
%
%        wlog=l_dtp2vp(wlog,varargin)
% INPUT
% wlog   log structure with a sonic curve
% varargin  new definitions of curve mnmonics of the form {'dtp','DTCO')
%        By default, the function uses the mnemonics of global structure
%        CURVES as defined in function "systemDefaults".
%	 The only possible "varargin" input can be re-definitions of
%	 curve mnemonics          
% OUTPUT
% wlog   log structure with all input curves and Vp

dummy=[];
[dummy,cm]=l_assign_input(dummy,varargin);

%	Check if log already has a P-velocity curve
[dummy,ier]=curve_index1(wlog,cm.vp);
if ier == 0
   alert('Well log already has a P-velocity curve.')
   return
end

[idtp,dummy]=curve_index1(wlog,cm.dtp);
if isempty(idtp)
   disp(' Log must have a P-sonic (DTP) curve')
   disp([' Curve mnemonics of log: ',cell2str(wlog.curve_info(:,1),', ')])
   error(' Abnormal termination')
else
   wlog.curves=[wlog.curves,1.0e6./wlog.curves(:,idtp)];
   if strcmpi(wlog.curve_info{idtp,2},'us/m')
      punits='m/s';
   elseif strcmpi(wlog.curve_info{idtp,2},'us/ft')
      punits='ft/s';
   else
      error([' Unknown units of sonic log: ',wlog.curve_info{idtp,2}]) 
   end 
   wlog.curve_info=[wlog.curve_info;{cm.vp,punits,'P-velocity'}]; 
   wlog=add_curve_type(wlog,{cm.vp,'Vp','acoustic velocity'});
end
