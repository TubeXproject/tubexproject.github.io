function x=cell2num(cx)
% Convert a cell array of numbers into a numeric array
%
% Written by: E. R.: March 1, 2006
% Last updated:
%
%
%          x=cell2num(cx)
% INPUT
% cx       cell array whos enries a numbers
% OUTPUT
% x        numeric array of the same dimension with the same numbers
%
% EXAMPLE
%          cell2num({1,2;3,4})

x=[cx{:}];
x=reshape(x,size(cx));
