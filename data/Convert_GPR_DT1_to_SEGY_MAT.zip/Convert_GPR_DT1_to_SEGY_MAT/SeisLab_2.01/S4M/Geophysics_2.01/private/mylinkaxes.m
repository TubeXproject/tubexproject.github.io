function mylinkaxes(handles,option)
% Depending on the Matlab version, the function uses "linkaxes" or 
% "linkedzoom" to link axes of a multi-plot figure to have a common zoom.
%
% Written by: E. R.: December 26, 2005
% Last updated:
%
% INPUT
% handles   handles of the axes to be linked
% option    Possible values are:
%           'x'   link x-axes
%           'y'   link y-axes
%           'xy'  link x-axes and y-axes

global S4M

if S4M.matlab_version < 7
   options={'x','y','xy','off'};
   loptions={'onx','ony2','onxy','off'};
   idx=find(ismember(options,option));
   if isempty(idx)
      error(['Option "',option,'" is not supported.'])
   end
   disable_zoom(gcf)
   linkedzoom(gcf,loptions{idx});
%   zoom off
else
   linkaxes(handles,option)
end
