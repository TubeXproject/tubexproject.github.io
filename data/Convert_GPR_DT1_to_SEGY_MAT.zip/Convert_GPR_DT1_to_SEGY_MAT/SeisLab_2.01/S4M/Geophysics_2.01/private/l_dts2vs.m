function wlog=l_dts2vs(wlog,varargin)
% Compute S-velocity from the shear sonic curve; if a V-shear curve alredy exists
% a message is printed to the command window and "wlog" is returned unchanged.
% To add an additional S-velocity give it a different name, e.g.
%              l_dts2vs(wlog,{'vs','new_vs'})
%
% Written by: E. R.: April 16, 2006
% Last updated:
%
%        wlog=l_dts2vs(wlog,varargin)
% INPUT
% wlog   log structure with a shear sonic curve
% varargin  new definitions of curve mnmonics of the form {'dts','DTSO')
%        By default, the function uses the mnemonics of global structure
%        CURVES as defined in function "systemDefaults".
%	 The only possible "varargin" input can be re-definitions of
%	 curve mnemonics          
% OUTPUT
% wlog   log structure with all input curves and Vs

dummy=[];
[dummy,cm]=l_assign_input(dummy,varargin);

%	Check if log already has a S-velocity curve
[dummy,ier]=curve_index1(wlog,cm.vs);
if ier == 0
   alert('Well log already has a P-velocity curve.')
   return
end

[idts,dummy]=curve_index1(wlog,cm.dts);
if isempty(idts)
   disp(' Log must have a shear-sonic (DTs) curve')
   disp([' Curve mnemonics of log: ',cell2str(wlog.curve_info(:,1),', ')])
   error(' Abnormal termination')
else
   wlog.curves=[wlog.curves,1.0e6./wlog.curves(:,idts)];
   if strcmpi(wlog.curve_info{idts,2},'us/m')
      punits='m/s';
   elseif strcmpi(wlog.curve_info{idts,2},'us/ft')
      punits='ft/s';
   else
      error([' Unknown units of shear sonic log: ',wlog.curve_info{idts,2}]) 
   end 
   wlog.curve_info=[wlog.curve_info;{cm.vs,punits,'S-velocity'}]; 
   wlog=add_curve_type(wlog,{cm.vs,'Vs','Shear velocity'});
end
