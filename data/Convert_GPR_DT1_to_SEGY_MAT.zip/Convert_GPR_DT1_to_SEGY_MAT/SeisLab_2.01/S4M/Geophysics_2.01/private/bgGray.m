function bgGray(axisHandle)
% Crate a gray axis backgrond; if S4M.invert_hardcopy is 'off' this 
% background is retained for printing

if nargin == 0
   axisHandle=gca;
end
set(gcf,'Color','w')
set(axisHandle,'Color',[0.9,0.9,0.9])
% set(gcf,'InvertHardcopy',S4M.invert_hardcopy)
