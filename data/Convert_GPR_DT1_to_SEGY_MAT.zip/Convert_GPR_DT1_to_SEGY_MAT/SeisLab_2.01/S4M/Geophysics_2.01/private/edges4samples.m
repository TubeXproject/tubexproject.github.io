function edges=edges4samples(smin,smax,delta)
% Compute edges for histogram calculation; all bins have the same width 
% Written by: E. R.: March 1, 2004
% Last updated: June 10, 2004: handle case when smin == smax (create one bin)
%
%        edges=edges4samples(smin,smax,delta)
% INPUT
% smin   smallest sample
% smax   largest sample
% delta  bin width
% OUTPUT
% edges  bin edges

span=smax-smin;
n=ceil(span/delta);
n=max(n,1);
width=n*delta;
delt=(width-span)*0.5;
edges=linspace(smin-delt,smax+delt,n+1);
