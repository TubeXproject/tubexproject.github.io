% File to be executed following the "quit" command
disp('Execution terminated')
% quit cancel