function initiate_3d_tracking(matrix,x,y,xinfo,yinfo,zinfo,bool,axis_handle)
% Initiate picking on a 2-d plot with with z-component)
% Written by: E. R.: September 14, 2003
% Last updated: December 10, 2005: use "setappdata" to store user data
%
%        initiate_3d_tracking(matrix,x,y,xinfo,yinfo,zinfo,bool,axis_handle)
% INPUT
% matrix  matrix of data plotted
% x      coordinates associared with columns
% y      coordinates associated with rows
% xinfo  info about x-coordinates; horizontal (optional)
% yinfo  info about y-coordinates; vertical (optional)
% zinfo  info about z-coordinates; values of matrix (optional)
% bool   logicl variable; if "bool" is true then menu button will be created
%        Default: function creates a button if it does not alredy exist
% axis_handle   handle of axis that should be tracked

if nargin < 8
   axis_handle=gca;
end

if nargin < 7
   bool=[];
end

if nargin < 6
   xinfo={'x','','x'};
   yinfo={'y','','y'};
   zinfo={'z','','z'};
end

if nargin <3
   [n,m]=size(matrix);
   x=1:m;
   y=1:n;
end

xlabel(info2label(xinfo));
ylabel(info2label(yinfo));
zlabel(info2label(zinfo));

%	Save userdata possibly stored with the axis handles
%setappdata(gcf,'userdata4axis',get(axis_handle,'UserData'));

	% Implement cursor tracking

% userdata.tag='display_cursor_location_3d';
userdata.userpointer='cross';
userdata.data=matrix;
userdata.ah=axis_handle;

userdata.x=x;
dx=diff(x);
if isconstant(dx,0.001);
   userdata.dx=mean(dx);
else
   userdata.dx=0;
end
userdata.constantx=isconstant(diff(x),0.001);
userdata.xformat='%8.5g';
userdata.xname=xinfo{1};
userdata.xunits=units4plot(xinfo{2});

userdata.y=y;
dy=diff(y);
if isconstant(dy,0.001);
   userdata.dy=mean(dy);
else
   userdata.dy=0;
end
userdata.yformat='%8.5g';
userdata.yname=yinfo{1};
userdata.yunits=units4plot(yinfo{2});

userdata.zformat='%8.5g';
userdata.zname=zinfo{1};
userdata.zunits=units4plot(zinfo{2});

setappdata(gca,'userdata_3d_tracking',userdata);

if isempty(bool)
   handle=findobj(gcf,'Tag','tracking_button');
   if isempty(handle)
      create_button4tracking({@display_cursor_location_3d});
   end
else
  if bool
     create_button4tracking(@display_cursor_location_3d);
  end
end
