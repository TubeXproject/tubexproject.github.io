function bool=isconstant(a,epsilon)
% Function checks if all elements of array "a" are the same within
% limits median(a)*(1 +/- epsilon) (relative error) or,
% if median(a) < eps, within limits +/- epsilon (absolute error).
%
% Written by: E. R.: November 14, 2005
% Last updated:
%
%          bool=isconstant(a,epsilon)
% INPUT
% a        numeric vector or matrix
% epsilon  maximum relative deviation 
%          Default: epsilon = 0
% OUTPUT
% bool     logical variable
%          true if all entries of "a" are the same within the limits
%          false  otherwise


if nargin == 1  |  epsilon == 0
   if all(a == a(1))
      bool=logical(1);
   else
      bool=logical(0);
   end

else
   ma=median(a);
   if abs(ma) < eps
      meps=abs(epsilon);
   else
      meps=abs(ma*epsilon);
   end
   if all(a <= ma+meps)  &  (a >= ma-meps)
      bool=logical(1);
   else
      bool=logical(0);
   end
end
