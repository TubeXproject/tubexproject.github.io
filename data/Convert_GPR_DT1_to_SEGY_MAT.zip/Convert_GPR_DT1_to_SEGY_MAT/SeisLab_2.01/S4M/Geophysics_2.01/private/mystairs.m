function handle=mystairs(x,y,style)
% Plots stair step graph; like "stairs, but with an "upstroke"
%
% Written by: E. R.: October 7, 2003
% Last updated: February 21, 2006: Handle Matlab 7
%
%           handle=mystairs(x,y,style)
% INPUT
% x         edges of stairs 
% y         level of stairs (the number of edges exceeds by 1 the number of
%           levels of the stairs; i.e. length(x)=length(y)+1 )
% style     optional plot linestyle
% OUTPUT
% handle(s) to stairstep graphs

global S4M

xx=[x(1);x(:)];
yy=[0;y(:);0];

if S4M.matlab_version < 7
   if nargin == 2
      handle=stairs(xx,yy);
   else
      handle=stairs(xx,yy,style);
   end
else
   if nargin == 2
      handle=stairs('v6',xx,yy);
   else
      handle=stairs('v6',xx,yy,style);
   end
end
