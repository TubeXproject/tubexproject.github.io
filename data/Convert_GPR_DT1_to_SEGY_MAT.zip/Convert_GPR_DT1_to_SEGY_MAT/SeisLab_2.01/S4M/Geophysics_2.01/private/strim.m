function s = strim(ss)
% Function removes trailing and leading blanks of a string.
% 
%        s=strim(ss)
% INPUT
% ss     strings whose leading and trailing blanks need to be removed
% OUTPUT
% s      string without leading and trailing blanks

global S4M

if S4M.matlab_version < 7
   s=fliplr(deblank(fliplr(deblank(ss))));
else
   s=strtrim(ss);
end
