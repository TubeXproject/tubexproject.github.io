function ds=real(ds)
% Function takes the imaginary part of the traces of a seismic dataset
%
% Written by: E. R.: August 9, 2006
% Last updated:

if isstruct(ds)  &  strcmp(ds.type,'seismic')
   ds.traces=imag(ds.traces);
else
   error('Operator "imag" is not defined for this argument.')
end
