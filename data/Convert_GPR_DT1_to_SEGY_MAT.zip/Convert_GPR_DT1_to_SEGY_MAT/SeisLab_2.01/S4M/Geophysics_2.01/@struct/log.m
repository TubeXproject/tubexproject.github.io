function ds=log(ds)
% Function takes the natural logarithm of the traces of a seismic dataset
% Written by: E. R.: November 23, 2005
% Last updated:

if isstruct(ds)  &  strcmp(ds.type,'seismic')
   ds.traces=log(ds.traces);
else
   error('Operator "log" is not defined for this argument.')
end
