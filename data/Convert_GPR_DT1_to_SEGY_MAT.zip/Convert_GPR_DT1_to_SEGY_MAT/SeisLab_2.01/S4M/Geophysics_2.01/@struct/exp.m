function ds=exp(ds)
% Function computes the exponential function of the traces of a seismic dataset
% Written by: E. R.: November 23, 2005
% Last updated:

if isstruct(ds)  &  strcmp(ds.type,'seismic')
   ds.traces=exp(ds.traces);
else
   error('Operator "exp" is not defined for this argument.')
end
