function ds=real(ds)
% Function takes the real part of the traces of a seismic dataset
%
% Written by: E. R.: August 9, 2006
% Last updated:

if isstruct(ds)  &  strcmp(ds.type,'seismic')
   ds.traces=real(ds.traces);
else
   error('Operator "real" is not defined for this argument.')
end
