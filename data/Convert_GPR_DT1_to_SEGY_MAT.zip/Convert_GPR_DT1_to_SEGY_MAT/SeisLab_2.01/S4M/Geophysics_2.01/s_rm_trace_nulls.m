function seismic=s_rm_trace_nulls(seismic,option)
% Remove NaN's at the beginning and end that are common to all traces;
% replace any other NaN's with zeros or leave them unchanged (see 
% argument "option").
% No action is taken if the field 'null' does not exist in the seismic data set.
%
% Written by: E. R.: July 12, 2000
% Updated: April 9, 2006: Streamline code, improve help section
%
%            seismic=s_rm_trace_nulls(seismic,option)
% INPUT
% seismic    seismic data set
% option     logical variable; If true all NaN's left after those at the 
%            beginning and end of the traces have been removed are replaced 
%            by zeros;  if false those NaN's are left in the data
%            Default: option=logical(1)
% OUTPUT
% seismic    seismic after NaN removal
%

global ABORTED S4M  

if ~isfield(seismic,'null')
   return
end

%	Remove NaN's
nsamp=size(seismic.traces,1);
seismic=rmfield(seismic,'null');
test=max(seismic.traces,[],2);
index=find(~isnan(test));
if isempty(index) 
   if S4M.interactive
      disp(' Seismic traces have only null values.')
      msgdlg('Seismic traces have only null values.')
      ABORTED=logical(1);
      return
   else
      error(' Seismic traces have only null values')
   end
end

%	Change start time and end time if necessary
if index(1) > 1  |  index(end) < nsamp
   seismic.traces=seismic.traces(index(1):index(end),:);
   seismic.first=seismic.first+(index(1)-1)*seismic.step;
   seismic.last=seismic.last-(nsamp-index(end))*seismic.step;
end

%	Deal with "interior" NaN's (if there are any)
if nargin == 1  |  option
   seismic.traces(isnan(seismic.traces))=0;
end

%	Update processing history
seismic=s_history(seismic,'append', ...
        [num2str(nsamp-size(seismic.traces,1)),' samples removed']);

ABORTED=logical(0);
