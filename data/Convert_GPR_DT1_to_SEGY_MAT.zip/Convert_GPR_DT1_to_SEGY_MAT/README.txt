% Written by Sajad Jazayeri, USF, OCT 2020


The GPR data at LBNM are collected with a PulseEkko system collecting dt1 binary files. To read and/or convert the dt1 files to .segy (convenstional SEG files) or .mat (matlab or octave readable) files, you need to run the "convertEkko2MatSegy.m" file in Matlab or Ocatve (free equivalent of Matlab). 

By runnuing this code, you will be directed to choose .dt1 file(s) and the code will automatically convert them to both .mat and .seg files.

You need to add 'SeisLab_2.01' or the newer versions of it (free online) to the Matlab or Octave PATH.

