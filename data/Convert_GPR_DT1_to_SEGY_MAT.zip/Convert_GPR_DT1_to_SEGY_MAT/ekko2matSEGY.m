function [A,x,t,timestamp,h,m,s]=ekko2matSEGY(filename) 
% 
% EKKO2MATSEGY syntax: [A,x,t]= ekko2matSEGY('filename') 
%                  where filename has no .hd/.dt1 extension 
% 
% This function reads a PulseEkko binary file into a MATLAB matrix 
% A: GPR data 
% x: distance along the profile (i.e. location of the antenna
% center)
% t: time series in ms
% timestamp: HHMMSS of data collection
% h: HH
% m: MM
% s: SS


% Originally developed by James Irving, Rock Physics, UBC 
% June, 1998 (M-File) 
%
% 1st updated by Sanaz Esmaeili, USF, 2017
% 2nd updated by Sajad Jazayeri, USF, 2020

  headerfile=[filename '.hd']; 
  datafile=[filename '.dt1']; 
  [fph,msg]=fopen(headerfile,'rt');  % open ASCII header file 
  if fph==-1                         % display error if necessary 
     disp(msg) 
     return 
  end 
  while(~feof(fph))                  % read information from header 
     temp=fgets(fph); 
     if (strncmp(temp,'NUMBER OF TRACES   =',20)) 
        ntraces=sscanf(temp(21:length(temp)),'%d'); 
     end 
     if (strncmp(temp,'NUMBER OF PTS/TRC  =',20))   % samples_per_trace
        nppt=sscanf(temp(21:length(temp)),'%d'); 
     end 
     if (strncmp(temp,'TIMEZERO AT POINT  =',20)) 
        zeropt=sscanf(temp(21:length(temp)),'%d'); 
     end 
     if (strncmp(temp,'TOTAL TIME WINDOW  =',20)) 
        window=sscanf(temp(21:length(temp)),'%d'); 
     end 
  end 
  fclose(fph); 


  [fpd,msg]=fopen(datafile,'rb','l'); % open binary data file 
  if fpd==-1                          % display error if necessary 
     disp(msg) 
     return 
  end 
  for j=1:ntraces                     % read data from file into A and x 
     fseek(fpd,4,0); 
     x(j)=fread(fpd,1,'float32');
     fseek(fpd,84,0); 
     ts(j)=fread(fpd,1,'float32');
     fseek(fpd,32,0); 
     A(:,j)=fread(fpd,nppt,'int16'); 
  end 

  fclose(fpd); 
  sampint=round((window/(nppt-1)*10))/10;   % create vertical time vector t 
  tstart=(zeropt-1)*(-sampint); 
  tend=tstart+(nppt-1)*sampint; 
  t=linspace(tstart,tend,nppt);
  [h,m,s,T]=sec2hms(ts);
  timestamp = [];
  timestamp = T';


    if t(end)>2  % meaning that the unit is in seconds and needs to be converted to ms
        t = t * 10^-6;
    end

    data = s_convert(A,0,(t(2) - t(1)));
    data.traces = A;
    data.first = 0;
    data.last = t(end);
    data.units = 'ms';
    data.nsamp = length (t)
    data.sou_x = x;
    data.sou_y = x;
    data.sou_elev = zeros(1,size(A,2));
    data.rec_x = x;
    data.rec_y = x;
    data.rec_elev = zeros(1,size(A,2));
    data.offset = ones(1,size(A,2));
    write_segy_file(data,strcat(filename,'.segy'))
        
      
save(strcat(filename,'.mat'),'A','timestamp','x','t')
disp('.mat file saved successfully');